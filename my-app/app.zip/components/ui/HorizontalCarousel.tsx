import React from "react";
import { FlatList, ViewStyle } from "react-native";

type HorizontalCarouselProps<T> = {
  items: T[];
  renderItem: ({ item }: { item: T }) => React.ReactElement;
  keyExtractor?: (item: T, index: number) => string;
  style?: ViewStyle;
};

export function HorizontalCarousel<T>({
  items,
  renderItem,
  keyExtractor,
  style,
}: HorizontalCarouselProps<T>) {
  return (
    <FlatList
      data={items}
      renderItem={renderItem}
      keyExtractor={keyExtractor ?? ((_, i) => i.toString())}
      horizontal
      showsHorizontalScrollIndicator={false}
      style={style}
    />
  );
}
