export default {
  regular: {
    fontFamily: "Sansation",
    fontSize: 15,
    color: "#ACA8A8",
  },
  bold: {
    fontFamily: "SansationBold",
  },
  title: {
    fontFamily: "Sansation",
    fontSize: 25,
    color: "#ffff",
  },
};