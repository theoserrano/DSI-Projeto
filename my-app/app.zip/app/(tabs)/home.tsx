import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { HorizontalCarousel } from "../components/HorizontalCarousel";

// Exemplo de tipos (ajuste conforme seu backend)
type Playlist = { id: string; title: string };
type Review = { id: string; user: string; song: string; text: string };

// Dados de exemplo (mock)
const playlists: Playlist[] = [
  { id: "1", title: "Minhas Favoritas" },
  { id: "2", title: "Top Rock" },
];

const reviews: Review[] = [
  { id: "1", user: "User A", song: "Song name", text: "Muito boa!" },
  { id: "2", user: "User B", song: "Outra música", text: "Top demais" },
];

export default function HomeScreen() {
  return (
    <View style={styles.container}>
      {/* Seção Minhas Playlists */}
      <Text style={styles.sectionTitle}>Suas playlists</Text>
      <HorizontalCarousel<Playlist>
        items={playlists}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.cardText}>{item.title}</Text>
          </View>
        )}
        keyExtractor={(item) => item.id}
      />

      {/* Seção Reviews */}
      <Text style={styles.sectionTitle}>Reviews</Text>
      <HorizontalCarousel<Review>
        items={reviews}
        renderItem={({ item }) => (
          <View style={styles.reviewCard}>
            <Text style={styles.reviewUser}>{item.user}</Text>
            <Text style={styles.reviewSong}>{item.song}</Text>
            <Text style={styles.reviewText}>{item.text}</Text>
          </View>
        )}
        keyExtractor={(item) => item.id}
      />

      {/* Seção Playlists recomendadas */}
      <Text style={styles.sectionTitle}>Playlists recomendadas</Text>
      <HorizontalCarousel<Playlist>
        items={playlists}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.cardText}>{item.title}</Text>
          </View>
        )}
        keyExtractor={(item) => "rec-" + item.id}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0a0a3c", // fundo azul escuro
    padding: 16,
  },
  sectionTitle: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold",
    marginVertical: 8,
  },
  card: {
    width: 120,
    height: 120,
    backgroundColor: "#ddd",
    borderRadius: 12,
    justifyContent: "center",
    alignItems: "center",
    marginRight: 12,
  },
  cardText: {
    color: "#000",
  },
  reviewCard: {
    width: 200,
    backgroundColor: "#00e0e0",
    borderRadius: 12,
    padding: 12,
    marginRight: 12,
  },
  reviewUser: {
    fontWeight: "bold",
    marginBottom: 4,
    color: "#000",
  },
  reviewSong: {
    fontSize: 14,
    marginBottom: 4,
    color: "#000",
  },
  reviewText: {
    fontSize: 12,
    color: "#000",
  },
});
