// app/(tabs)/friends.tsx
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';

type Friend = {
  id: string;
  name: string;
};

const mockFriends: Friend[] = [
  { id: '1', name: 'Username' },
  { id: '2', name: 'Username' },
  { id: '3', name: 'Username' },
  { id: '4', name: 'Username' },
  { id: '5', name: 'Username' },
];

export default function Friends() {
  const router = useRouter();

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="chevron-back" size={24} color="white" />
        </TouchableOpacity>
        <Text style={styles.title}>Amigos</Text>
        <View style={{ width: 24 }} />
      </View>

      <FlatList
        data={mockFriends}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ padding: 16 }}
        renderItem={({ item }) => (
          <View style={styles.friendRow}>
            <View style={styles.avatarCircle}>
              <Text style={styles.avatarLetter}>{item.name.charAt(0)}</Text>
            </View>
            <Text style={styles.friendName}>{item.name}</Text>
            <TouchableOpacity style={styles.menuButton}>
              <Ionicons name="ellipsis-vertical" size={20} color="white" />
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#07103B',
  },
  header: {
    paddingTop: 50,
    paddingHorizontal: 12,
    paddingBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomColor: '#152042',
    borderBottomWidth: 1,
    justifyContent: 'space-between',
  },
  title: {
    color: 'white',
    fontSize: 18,
    fontWeight: '700',
  },
  friendRow: {
    backgroundColor: '#08102A',
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatarCircle: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: '#19233F',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  avatarLetter: {
    color: 'white',
    fontWeight: '700',
  },
  friendName: {
    flex: 1,
    color: 'white',
    fontSize: 16,
  },
  menuButton: {
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 8,
    borderColor: '#25324D',
    borderWidth: 1,
  },
});
