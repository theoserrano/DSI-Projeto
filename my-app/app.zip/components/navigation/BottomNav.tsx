// components/navigation/BottomNav.tsx
import React from "react";
import { View, TouchableOpacity } from "react-native";
import { BottomTabBarProps } from "@react-navigation/bottom-tabs";
import Ionicons from "@expo/vector-icons/Ionicons";

export function BottomNav({ state, descriptors, navigation }: BottomTabBarProps) {
  return (
    <View
      style={{
        flexDirection: "row",
        justifyContent: "space-around",
        alignItems: "center",
        backgroundColor: "#000B3A",
        paddingVertical: 10,
      }}
    >
      {state.routes.map((route, index) => {
        const { options } = descriptors[route.key];
        const label =
          options.tabBarLabel !== undefined
            ? options.tabBarLabel
            : options.title !== undefined
            ? options.title
            : route.name;

        const isFocused = state.index === index;

        // Ícones customizados baseados no nome da rota
        let iconName: keyof typeof Ionicons.glyphMap = "home-outline";
        if (route.name === "home") iconName = "home-outline";
        if (route.name === "search") iconName = "search-outline";
        if (route.name === "create") iconName = "add-circle-outline";
        if (route.name === "profile") iconName = "person-outline";
        if (route.name === "notifications") iconName = "notifications-outline";
        if (route.name === "friends") iconName = "people-outline";

        return (
          <TouchableOpacity
            key={route.key}
            accessibilityRole="button"
            accessibilityState={isFocused ? { selected: true } : {}}
            onPress={() => navigation.navigate(route.name as never)}
            style={{ alignItems: "center" }}
          >
            <Ionicons
              name={iconName}
              size={28}
              color={isFocused ? "#4CAF50" : "#fff"}
            />
          </TouchableOpacity>
        );
      })}
    </View>
  );
}
