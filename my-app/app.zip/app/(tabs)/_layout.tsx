import { Tabs } from 'expo-router';
import React from 'react';
import { BottomNav } from '@/components/navigation/BottomNav';

export default function TabsLayout() {
  return (
    <Tabs
      screenOptions={{ headerShown: false }}
      tabBar={(props) => <BottomNav {...props} />}
    >
      <Tabs.Screen name="home" />
      <Tabs.Screen name="search" />
      <Tabs.Screen name="create" />
      <Tabs.Screen name="profile" />
      <Tabs.Screen name="notifications" />
      <Tabs.Screen name="friends" />
    </Tabs>
  );
}
